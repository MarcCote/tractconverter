================
 TractConverter
================

TractConverter is a python toolbox to convert tractogram files.

TractConverter is for research only; please do not use results
from TractConverter on clinical data.

Website
=======

N/A

Mailing Lists
=============

N/A

Code
====

You can find our sources and single-click downloads:

* `Main repository`_ on Github.
* Documentation_ for all releases and current development tree.
* Download as a tar/zip file the `current trunk`_.
* Downloads of all `available releases`_.

.. _main repository: http://github.com/MarcCote/tractconverter
.. _Documentation: N/A
.. _current trunk: http://github.com/MarcCote/tractconverter/master
.. _available releases: N/A

License
=======

tractconverter is licensed under the terms of the BSD license. Some code included with
tractconverter is also licensed under the BSD license.  Please the LICENSE file in the
tractconverter distribution.
