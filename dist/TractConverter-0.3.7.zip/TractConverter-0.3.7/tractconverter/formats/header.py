'''
Created on 2012-02-22

@author: coteharn
'''

class Header():
    NB_FIBERS = 0
    STEP = 1
    METHOD = 2
    NB_SCALARS_BY_POINT = 3
    NB_PROPERTIES_BY_TRACT = 4
    