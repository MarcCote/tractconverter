# -*- coding: UTF-8 -*-

#Documentation available here:
#http://www.trackvis.org/docs/?subsect=fileformat

import os
import numpy as np

from tractconverter.formats.header import Header


def readBinaryBytes(f, nbBytes, dtype):
    buff = f.read(nbBytes * dtype.itemsize)
    return np.frombuffer(buff, dtype=dtype)

class TRK:
    MAGIC_NUMBER = "TRACK"
    OFFSET = 1000
    #self.hdr
    #self.filename
    #self.endian
    #self.FIBER_DELIMITER
    #self.END_DELIMITER
    
    #####
    #Static Methods
    ###
    @staticmethod
    def create(filename, hdr, anatFile=None):
        f = open(filename, 'wb')
        f.write(TRK.MAGIC_NUMBER + "\n")
        f.close()
        
        trk = TRK(filename, load=False)
        trk.hdr = hdr
        trk.writeHeader();

        return trk

    #####
    #Methods
    ###
    def __init__(self, filename, anatFile=None, load=True):
        self.filename = filename
        if not self._check():
            raise NameError("Not a TRK file.")
        
        self.hdr = {}
        if load:
            self._load()
    
    def _check(self):
        f = open(self.filename, 'rb')
        magicNumber = f.read(5)
        f.close()
        return magicNumber == self.MAGIC_NUMBER
    

    def _load(self):
        f = open(self.filename, 'rb')
        
        #####
        #Read header
        ###
        f.seek(self.OFFSET-4-4-4) #Skip to n_count
        
        buffer = f.read(4+4+4)
        infos = np.frombuffer(buffer, dtype='<i4')
        
        #Check if little or big endian
        self.endian = '<'
        if infos[2] != 1000:
            infos = np.frombuffer(buffer, dtype='>i4')
            self.endian = '>'
        
        self.hdr[Header.NB_FIBERS] = infos[0]
        if self.hdr[Header.NB_FIBERS] == 0:
            #NbFibers not provided, let's count manually...
            
            #TODO: Take in count, scalars and properties
            remainingBytes = os.path.getsize(self.filename) - self.OFFSET
            while remainingBytes > 0:
                #Read points
                nbPoints = readBinaryBytes(f, 1, np.dtype(self.endian + "i4"))[0]
                f.seek(nbPoints*3*4, 1) #Relative seek
                remainingBytes -= nbPoints*3*4 + 4
                self.hdr[Header.NB_FIBERS] += 1
        
        f.close()
            
    def writeHeader(self):
        f = open(self.filename, 'wb')
        f.write(self.MAGIC_NUMBER + " ")
        f.write(np.zeros(self.OFFSET-4-4-4-6, dtype='i1'))
        f.write(np.array([self.hdr[Header.NB_FIBERS], 2, self.OFFSET], dtype='<i4'))
        f.close()
        
    def close(self):
        pass

    def __iadd__(self, fibers):
        f = open(self.filename, 'ab')
        for fib in fibers:
            f.write(np.array([len(fib)], '<i4').tostring())
            f.write(fib.tostring())
        f.close()
        
        return self
        
            
    #####
    #Iterate through fibers
    ###
    def __iter__(self):
        f = open(self.filename, 'rb')
        f.seek(self.OFFSET)
        
        remainingBytes = os.path.getsize(self.filename) - self.OFFSET

        cpt = 0
        while cpt < self.hdr[Header.NB_FIBERS] or remainingBytes > 0:
            #Read points
            nbPoints = readBinaryBytes(f, 1, np.dtype(self.endian + "i4"))[0]
            pts = readBinaryBytes(f, nbPoints*3, np.dtype(self.endian + "f4"))
            
            yield pts.reshape([-1, 3])
            
            remainingBytes -= nbPoints*3*4 + 4
            cpt += 1
            
        f.close()
