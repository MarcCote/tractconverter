'''
Created on 2012-02-22

@author: coteharn
'''

class Header():
    NB_FIBERS, \
    STEP, \
    METHOD = range(3)