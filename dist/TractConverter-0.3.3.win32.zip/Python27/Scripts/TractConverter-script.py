#!C:\Python27\python.exe
# EASY-INSTALL-ENTRY-SCRIPT: 'TractConverter==0.3.3','console_scripts','TractConverter'
__requires__ = 'TractConverter==0.3.3'
import sys
from pkg_resources import load_entry_point

if __name__ == '__main__':
    sys.exit(
        load_entry_point('TractConverter==0.3.3', 'console_scripts', 'TractConverter')()
    )
